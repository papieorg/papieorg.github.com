<!--To Create Menus
function mmLoadMenus() {
  if (window.mm_menu_0324093759_0) return;
          window.mm_menu_0324093759_0 = new Menu("root",130,22,"Arial, Helvetica, sans-serif",10,"#505050","#FFFFFF","#CECECF","#386FAD","left","middle",3,0,800,-5,7,true,false,true,2,false,false);
  mm_menu_0324093759_0.addMenuItem("Mission,&nbsp;Vision,&nbsp;Values","location='../01_About/Mission.html'");
  mm_menu_0324093759_0.addMenuItem("History","location='../01_About/History.html'");
  mm_menu_0324093759_0.addMenuItem("Financial&nbsp;Performance","location='../01_About/Financials.html'");
  mm_menu_0324093759_0.addMenuItem("Report&nbsp;to&nbsp;the&nbsp;Community","location='http://www.papie.org/annualReport_2009_nodonor.pdf'");
  mm_menu_0324093759_0.addMenuItem("Board&nbsp;of&nbsp;Directors","location='../01_About/BOD.html'");
  mm_menu_0324093759_0.addMenuItem("Advisory&nbsp;Council","location='../01_About/AdvisoryCouncil.html'");
  mm_menu_0324093759_0.addMenuItem("Volunteers&nbsp;&amp;&nbsp;Staff","location='../01_About/VolunteersStaff.html'");
   mm_menu_0324093759_0.hideOnMouseOut=true;
   mm_menu_0324093759_0.bgColor='#555555';
   mm_menu_0324093759_0.menuBorder=1;
   mm_menu_0324093759_0.menuLiteBgColor='#FFFFFF';
   mm_menu_0324093759_0.menuBorderBgColor='#777777';
  window.mm_menu_0324094724_0 = new Menu("root",130,22,"Arial, Helvetica, sans-serif",10,"#505050","#FFFFFF","#CECECF","#386FAD","left","middle",3,0,1000,-5,7,true,false,true,2,false,false);
  mm_menu_0324094724_0.addMenuItem("Schools&nbsp;Campaign","location='../02_OurImpact/SchoolCampaign.html'");
  mm_menu_0324094724_0.addMenuItem("Teacher&nbsp;Grants","location='../02_OurImpact/TeacherGrants.html'");
  mm_menu_0324094724_0.addMenuItem("Community&nbsp;Support","location='../02_OurImpact/CommunitySupport.html'");
//  mm_menu_0324094724_0.addMenuItem("PiE&nbsp;Fair","location='../02_OurImpact/piefair.html'");
   mm_menu_0324094724_0.hideOnMouseOut=true;
   mm_menu_0324094724_0.bgColor='#555555';
   mm_menu_0324094724_0.menuBorder=1;
   mm_menu_0324094724_0.menuLiteBgColor='#FFFFFF';
   mm_menu_0324094724_0.menuBorderBgColor='#777777';
  window.mm_menu_0324095416_0 = new Menu("root",130,22,"Arial, Helvetica, sans-serif",10,"#505050","#FFFFFF","#CECECF","#386FAD","left","middle",3,0,1000,-5,7,true,false,true,2,false,false);
  mm_menu_0324095416_0.addMenuItem("Ways&nbsp;to&nbsp;Give","location='../03_Donate/WaysToGive.html'");
  mm_menu_0324095416_0.addMenuItem("Personal&nbsp;Donations","location='../03_Donate/PersonalDonations.html'");
  mm_menu_0324095416_0.addMenuItem("Leadership&nbsp;Circle","location='../03_Donate/LeadershipCircle.html'");
   mm_menu_0324095416_0.hideOnMouseOut=true;
   mm_menu_0324095416_0.bgColor='#555555';
   mm_menu_0324095416_0.menuBorder=1;
   mm_menu_0324095416_0.menuLiteBgColor='#FFFFFF';
   mm_menu_0324095416_0.menuBorderBgColor='#777777';
  window.mm_menu_0324095516_0 = new Menu("root",130,22,"Arial, Helvetica, sans-serif",10,"#505050","#FFFFFF","#CECECF","#386FAD","left","middle",3,0,1000,-5,7,true,false,true,2,false,false);
  mm_menu_0324095516_0.addMenuItem("Press&nbsp;Releases","location='../04_News/News.html'");
  mm_menu_0324095516_0.addMenuItem("Media&nbsp;Coverage","location='../04_News/MediaCoverage.html'");
  mm_menu_0324095516_0.addMenuItem("Newsletters","location='../04_News/Newsletters.html'");
  mm_menu_0324095516_0.addMenuItem("Other&nbsp;Materials","location='../04_News/othermaterials.html'");
   mm_menu_0324095516_0.hideOnMouseOut=true;
   mm_menu_0324095516_0.bgColor='#555555';
   mm_menu_0324095516_0.menuBorder=1;
   mm_menu_0324095516_0.menuLiteBgColor='#FFFFFF';
   mm_menu_0324095516_0.menuBorderBgColor='#777777';


mm_menu_0324095516_0.writeMenus();
} // mmLoadMenus()
