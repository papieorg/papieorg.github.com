<?php
if ($_GET['randomId'] != "cN5QC3yWUt5wD90MwXt9kcRcTZHgEfpl6u2UWTnFACw3rX05pZe__8T8Oap3cTRV") {
    echo "Access Denied";
    exit();
}

// display the HTML code:
echo stripslashes($_POST['wproPreviewHTML']);

?>  
