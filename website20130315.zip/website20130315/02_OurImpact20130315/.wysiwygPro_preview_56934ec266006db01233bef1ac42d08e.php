<?php
if ($_GET['randomId'] != "P8VmHV8VZBWcXinULrS9jekgpSNG5mJ7aSYmJAR7QtLOe6FMuKtmwm2szdOzfLEO") {
    echo "Access Denied";
    exit();
}

// display the HTML code:
echo stripslashes($_POST['wproPreviewHTML']);

?>  
